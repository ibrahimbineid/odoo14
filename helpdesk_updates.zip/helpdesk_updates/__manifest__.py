# -*- coding: utf-8 -*-
{
    'name': 'Helpdesk Updates',
    'version': '13.0.1',
    'summary': 'Helpdesk Updates',
    'category': 'helpdesk',
    'author': 'Magdy, TeleNoc',
    'description': """
    Helpdesk Updates
    """,
    'depends': ['helpdesk', 'maintenance'],
    'data': [
        'views/helpdesk_view.xml',
    ]
}
